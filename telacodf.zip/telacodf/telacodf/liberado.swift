//
//  liberado.swift
//  telacodf
//
//  Created by User on 08/12/23.
//

import SwiftUI

struct liberado: View {
    var body: some View {
        Text(/*@START_MENU_TOKEN@*/"Hello, World!"/*@END_MENU_TOKEN@*/)
    }
}

#Preview {
    liberado()
}
