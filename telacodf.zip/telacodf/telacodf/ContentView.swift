//
//  ContentView.swift
//  telacodf
//
//  Created by User on 08/12/23.
//

//
//  ContentView.swift
//  telacod
//
//  Created by User on 08/12/23.
//

import SwiftUI

struct ContentView: View {
    @State private var password = ""
    @State private var wrongPassword =  0
    @State private var showingLoginScreen = false
    
    
    var body: some View {
        NavigationView{
            VStack (spacing: 50){
 
                Spacer(minLength: 100)
                 Image("garfograu")
                    .resizable()
                    .frame(width: 150, height:110)
                    .padding(20)
                
                SecureField("Senha", text:$password)
                    .frame(width: 300)
                    .padding()
                    .background(Color.black.opacity(0.05))
                    .cornerRadius(10)
                    .border(.red, width: CGFloat(wrongPassword))
                
                Button(action: {
                    autheticaPass(passaword: password)
                }) {Label: do {
                    Text("LIBERAR")
                        .font(.headline)
                        .frame(width: 100, height:18)
                        .foregroundColor(.black)
                        .padding()
                        .background()
                        .background(Color.white)
                        .cornerRadius(40)
                        .overlay(
                            RoundedRectangle(cornerRadius: 10)
                                .stroke(Color.black, lineWidth: 1)
)
                }}
    
                
                NavigationLink( destination: Text("ola"), isActive: $showingLoginScreen){
                    
                }
                HStack{
                    EImage("rosa", nameImgE: "amarelo")
                        .frame(alignment: .bottom)
                        .offset(y: 54)
                        
                }
            }
            .navigationBarHidden(true)
        }
        
    }
    func autheticaPass(passaword: String){
        if passaword.lowercased() == "1234" {
            wrongPassword = 0
            showingLoginScreen = true
        } else {
            wrongPassword = 2
        }
        
    }
}


#Preview {
    ContentView()
}

