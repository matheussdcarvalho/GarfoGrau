//
//  telacodfApp.swift
//  telacodf
//
//  Created by User on 08/12/23.
//

import SwiftUI

@main
struct telacodfApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
