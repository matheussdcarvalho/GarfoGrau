//
//  Avaliacao.swift
//  GarfoGrauT2
//
//  Created by User on 05/12/23.
//

import Foundation
