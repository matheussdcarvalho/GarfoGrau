//
//  Estrelas.swift
//  GGatu
//
//  Created by User on 04/12/23.
//

import SwiftUI

struct AvaliacaoView: View {
    var body: some View {
        VStack{
            Image("GVector")
                .frame(height: 100)
                .overlay {
                    Text("CARDÁPIO")
                        .font(.system(size: 30))
                        .bold()
                        .offset(y: -45)
                }
        
                .offset(x:0,y:-100)
            }
        }
    }
#Preview {
    AvaliacaoView()
}
