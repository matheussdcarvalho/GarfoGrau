//
//  GarfoGrauT2App.swift
//  GarfoGrauT2
//
//  Created by User on 24/10/23.
//

import SwiftUI

@main
struct GarfoGrauT2App: App {
    var body: some Scene {
        WindowGroup {
            EscolhaView()
        }
    }
}
