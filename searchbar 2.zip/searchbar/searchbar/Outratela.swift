//
//  Outratela.swift
//  searchbar
//
//  Created by user on 11/12/23.
//

/*import Foundation
struct OutraTelaView: View {
   var body: some View {
       VStack {
           // Conteúdo da outra tela
           Text("Outra Tela")
           Text("Você chegou à outra tela!")
       }
       .navigationBarTitle("Outra Tela")
   }
}

struct ContentView_Previews: PreviewProvider {
   static var previews: some View {
       ContentView()
   }*/
