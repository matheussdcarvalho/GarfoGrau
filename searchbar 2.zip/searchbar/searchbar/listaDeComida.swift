//
//  listadeComida.swift
//  searchbar
//
//  Created by user on 04/12/23.

import SwiftUI
import Foundation
public var listaDeComida: [(nome: String, imagem: String)] = [
    ("Água de coco", "agua"),
    ("Burrito", "burrito"),
    ("Sorvete", "sorvete")
]
