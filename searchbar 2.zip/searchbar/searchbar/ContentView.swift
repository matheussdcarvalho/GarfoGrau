//
//  ContentView.swift
//  searchbar
//
//  Created by user on 24/11/23.
//
import SwiftUI

struct ContentView: View {
    private var listaDePratos = listaDeComida
    @State private var searchText = ""
    @State private var selectedComidas: Set<String> = []
    
    var body: some View {
        NavigationView {
            List {
                ForEach(comidas, id: \.nome) { comida in
                    HStack {
                       /*  Image(comida.imagem)
                         .resizable()
                         .scaledToFit()
                         .clipShape(Circle())
                         .frame(width: 50, height: 80)*/
                        
                        
                        
                        VStack(alignment: .leading) {
                            Text(comida.nome.capitalized)
                                .font(.system(size:20))
                                .font(.headline)
                                .offset(y: 20)
                            
                            
                            
                            //Spacer()
                            
                            HStack {
                         
                                Spacer()
                                Button(action: {
                                    toggleSelection(comida)
                                }) {
                                    Image(systemName: selectedComidas.contains(comida.nome) ? "checkmark.circle.fill" : "plus.circle")
                                        .font(.system(size:25))
                                        .foregroundColor(selectedComidas.contains(comida.nome) ? .green : .blue)
                                    
                                }
                            }
                        }
                    }
                    .padding()
                }
            }
            .padding()
        }
        .searchable(text: $searchText)
        .navigationTitle("Produtos")
    }
    
    var comidas: [(nome: String, imagem: String)] {
        let lcComidas = listaDePratos.map { ($0.nome.lowercased(), $0.imagem) }
        
        return searchText.isEmpty ? lcComidas : lcComidas.filter {
            $0.0.contains(searchText.lowercased())
        }
    }
    
    private func toggleSelection(_ comida: (nome: String, imagem: String)) {
        if selectedComidas.contains(comida.nome) {
            selectedComidas.remove(comida.nome)
        } else {
            selectedComidas.insert(comida.nome)
        }
    }
}


struct ContentView_Preview: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
