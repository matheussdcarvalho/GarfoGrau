//
//  searchbarApp.swift
//  searchbar
//
//  Created by user on 24/11/23.
//

import SwiftUI

@main
struct searchbarApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
